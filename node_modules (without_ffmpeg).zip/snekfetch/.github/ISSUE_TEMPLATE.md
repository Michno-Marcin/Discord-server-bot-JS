Snekfetch version or commit hash:


Explaination of issue:


Example code to reproduce:
```js
// code here
```


- [ ] Issue occurs in browser
- [ ] Issue occurs in node
